java-rpg
========

old-fashioned role playing game using Java

<img src="https://raw.github.com/sylvan5/java-rpg/master/java-rpg.png" />
